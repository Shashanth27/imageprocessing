-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ashwath
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher` (
  `TID` int NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `ct` varchar(3) DEFAULT NULL,
  `bd` varchar(3) DEFAULT NULL,
  `contact` bigint DEFAULT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher`
--

LOCK TABLES `teacher` WRITE;
/*!40000 ALTER TABLE `teacher` DISABLE KEYS */;
INSERT INTO `teacher` VALUES (1,'Alice Johnson',35,'1988-04-15','12A','B+',9876543210),(2,'John Smith',42,'1981-12-02','12B','A+',8765432109),(3,'Maria Garcia',29,'1994-08-20','12C','A-',7654321098),(5,'Sarah Kin',31,'1992-11-30','12E','B+',5432109876),(6,'Ahmed Ahmed',38,'1985-07-18','11A','O+',4321098765),(7,'Elena Petrova',40,'1983-03-25','11B','O+',3210987654),(8,'Carlos Lopez',34,'1989-09-14','11C','B+',2109876543),(9,'Emily White',28,'1995-06-07','11D','A+',1098765432),(10,'David Lee',45,'1978-02-13','11E','O+',987654321),(11,'Fatima Khan',32,'1991-10-05','12C','B-',9555555555),(12,'Miguel Sanchez',39,'1984-01-22','12B','A+',8444444444),(13,'Andrea Rossi',36,'1987-07-03','12E','A+',7333333333),(14,'Anna Wang',33,'1990-04-28','12A','O+',6222222222),(15,'Pedro Hernandez',43,'1980-08-12','12D','B+',5111111111),(16,'Olivia Turner',30,'1993-12-15','11A','B+',4000000000),(17,'Mohamed Ali',37,'1986-06-01','11C','A+',3111111111),(18,'Sophie Martin',44,'1979-10-19','11D','A-',2222222222),(19,'Hiroshi Tanaka',27,'1996-03-08','11E','B+',1333333333),(20,'Natalia Ivanova',46,'1977-09-23','11B','O+',444444444),(21,'Rajesh Kumar',35,'1988-04-15','12C','AB-',9777777777),(22,'Priya Sharma',42,'1981-12-02','12B','B+',8666666666),(23,'Amit Patel',29,'1994-08-20','12A','B+',7555555555),(24,'Deepak Gupta',47,'1976-05-10','12D','O+',6444444444),(25,'Sneha Verma',31,'1992-11-30','12E','A+',5333333333),(26,'Neha Singh',38,'1985-07-18','11A','AB+',4222222222),(27,'Rohit Reddy',40,'1983-03-25','11D','B+',3111111111),(28,'Anjali Desai',34,'1989-09-14','11B','O+',2000000000),(29,'Sanjay Choudhury',28,'1995-06-07','11E','A+',1888888888),(30,'Sarika Joshi',45,'1978-02-13','11C','AB+',777777777),(31,'Prakash Tiwari',32,'1991-10-05','12A','B+',9666666666),(32,'Deepa Mishra',39,'1984-01-22','12B','O+',8555555555),(33,'Manish Singh',36,'1987-07-03','12C','A+',7444444444),(34,'Smita Kapoor',33,'1990-04-28','12D','A-',6333333333),(35,'Vikram Rajput',43,'1980-08-12','12E','B+',5222222222),(36,'Anju Sharma',30,'1993-12-15','11A','O+',4111111111),(37,'Rajat Dubey',37,'1986-06-01','11B','A+',3000000000),(38,'Meera Yadav',44,'1979-10-19','11C','AB+',1999999999),(39,'Preeti Bhat',27,'1996-03-08','11D','B+',888888888),(40,'Ajay Pandey',46,'1977-09-23','11E','B+',9777777777),(41,'Edward D Souza',35,'1988-04-15','12A','A+',8666666666),(42,'Lorraine Fernandes',42,'1981-12-02','12B','A+',7555555555),(43,'Philip D Cruz',29,'1994-08-20','12C','A-',6444444444),(44,'Charlotte Pereira',47,'1976-05-10','12D','B+',533333333),(45,'Oliver D Mello',31,'1992-11-30','12E','O+',4222222222),(46,'Isabel D Costa',38,'1985-07-18','11A','O+',3111111111),(47,'Diana Rodrigues',40,'1983-03-25','11B','A+',2000000000),(48,'Walter D Silva',34,'1989-09-14','11C','B+',1888888888),(49,'Grace D Cunha',28,'1995-06-07','11D','B+',777777777),(50,'Durairaj Selvakumar',43,'1978-11-04','12E','B-',1234509876);
/*!40000 ALTER TABLE `teacher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-24 21:01:21
