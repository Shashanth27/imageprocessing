-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ashwath
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `old_student`
--

DROP TABLE IF EXISTS `old_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `old_student` (
  `TCID` int NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `passout_year` varchar(4) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `bd` varchar(5) DEFAULT NULL,
  `contact` bigint DEFAULT NULL,
  PRIMARY KEY (`TCID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `old_student`
--

LOCK TABLES `old_student` WRITE;
/*!40000 ALTER TABLE `old_student` DISABLE KEYS */;
INSERT INTO `old_student` VALUES (12,'Joe','Biden','2024','2009-09-10','B+',9840987625),(15,'Riyaa','Junior','2022','2007-04-15','B+',9654341097),(35,'Ritaa','Goes','2024','2007-04-15','B+',9654341097),(38,'Anaya','Chamber','2022','2007-04-15','B+',3454352097),(45,'Ashwath','Narayanan','2022','2006-06-15','A+',9764341097),(75,'Jim','Moriaty','2022','2007-04-15','B+',9604348997),(100,'Sus','Mesii','2024','2006-04-15','B+',9654341097),(178,'Sus','Venkat','2024','2007-04-15','B+',9305648997),(185,'Roja','Poomalai','2024','2006-04-15','A+',9942341097),(248,'Leo','Das','2024','2006-02-06','B+',90341340096),(265,'Pow','Gnangavel','2020','2006-04-15','B+',9654341097),(280,'Rishwin','Saicharan','2020','2007-03-21','A+',9482659026),(345,'Joe','Thangavel','2022','2007-03-15','B+',9654341097),(440,'Alisa','John','2022','2006-02-06','B+',91341560096),(456,'Ashwath','Kumari','2024','2007-04-15','B+',9454452097),(658,'Pand','Neymar','2024','2006-02-06','B+',8634340096),(678,'Joe','Venar','2024','2006-02-06','B+',8634340096),(708,'Umar','Yoru','2024','2007-04-15','B+',9654341097),(768,'Anaya','Chamber','2020','2007-04-15','B+',9454352097);
/*!40000 ALTER TABLE `old_student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-24 21:01:21
